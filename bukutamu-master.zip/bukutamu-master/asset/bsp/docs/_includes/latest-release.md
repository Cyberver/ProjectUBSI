### Latest release (2019-05-11)

### 1.2.1

- **New:** Added font-awesome svg support.
- **New:** Added `size` option of the input group.

### 1.2.0

- **New:** Rewrote the src to ES6.
- **New:** Supported bootstrap v4.
- **New:** Use Font Awesome v5 as default.
- **New:** Supported `maxlength` attribute.
- **New:** Supported `disabled` attribute.
- **New:** Updated the docs and added examples.
